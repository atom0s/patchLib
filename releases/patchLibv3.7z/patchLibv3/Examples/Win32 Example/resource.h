//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resources.rc

#define IDB_FRAME                       1000
#define IDI_ICON                        2000
#define IDC_CURSOR                      3000
#define IDR_FONT                        4000
#define IDB_MUSIC						4001
#define IDB_COPY						4002
#define IDB_EXIT						4003
#define IDM_MUSIC						4004
#define IDR_TEMPLATE					5000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
